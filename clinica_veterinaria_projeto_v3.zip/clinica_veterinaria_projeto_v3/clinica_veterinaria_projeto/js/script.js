document.addEventListener('DOMContentLoaded', () => {
  // Confirmação interativa de agendamento online no formulário
  const form = document.querySelector('form');
  if (form) {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const nome = document.getElementById('nome')?.value || 'Tutor';
      alert(`Obrigado, ${nome}! Solicitação de agendamento recebida. A equipe do Centro Veterinário Seres entrará em contato em breve.`);
      form.reset();
    });
  }

  // Efeito suave ao clicar nos links de navegação
  const links = document.querySelectorAll('a[href^="#"]');
  links.forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const target = document.querySelector(link.getAttribute('href'));
      if (target) {
        target.scrollIntoView({ behavior: 'smooth' });
      }
    });
  });
});
